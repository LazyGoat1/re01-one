﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class admin2 : Form
    {
        public admin2()
        {
            InitializeComponent();
            Table();
        }

        private void admin2_Load(object sender, EventArgs e)
        {
            Table();
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }
        /// <summary>
        /// 从数据库读取显示在表格控件中的方法  类似刷新
        /// </summary>
        public void Table()
        {
            dataGridView1.Rows.Clear(); // 清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from t_book";
            IDataReader dc = dao.read(sql); // 读取数据库到的数据返回到dc
            // 可以定义
            //string a0, a1, a2, a3, a4; // 来接收dc中的数据
            while (dc.Read())
            {
                // 这个方法 可以更好的修改数据 或添加数据
                //a0 = dc[0].ToString();
                //string[] table = { a0, a1, a2, a3, a4 };
                //dataGridView1.Rows.Add(table);

                // 一行一行的进行读写 这个方法简单粗暴
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());

            }
            dc.Close();
            dao.DaoClose();
        }
        /// <summary>
        /// 根据书号显示数据
        /// </summary>
        public void TableID()
        {
            dataGridView1.Rows.Clear(); // 清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from t_book where id='{textBox1.Text}'";
            IDataReader dc = dao.read(sql); // 读取数据库到的数据返回到dc         
            while (dc.Read())
            {    
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        /// <summary>
        /// 根据书名显示数据 模糊查询
        /// </summary>
        public void TableName()
        {
            dataGridView1.Rows.Clear(); // 清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from t_book where name like'%{textBox2.Text}%'";
            IDataReader dc = dao.read(sql); // 读取数据库到的数据返回到dc         
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            admin21 admin = new admin21();
            admin.ShowDialog();
            Table();// 重新获取数据
        }
        /// <summary>
        /// 删除图书
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Rows[0] 第下标为0行 下标为0的单元格的值 
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                label2.Text = id + dataGridView1.SelectedRows[0].Cells[1].Value.ToString(); // id+书名
                DialogResult dr = MessageBox.Show("确认删除吗？(#^.^#)", "信息提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.OK)
                {
                    string sql = $"delete from t_book where id='{id}'";
                    Dao dao = new Dao();
                    if (dao.Execute(sql) > 0) // 大于0 说明 语句执行成功
                    {
                        MessageBox.Show("删除成功");
                        Table(); // 重新获取数据

                    }
                    else
                    {
                        MessageBox.Show("删除失败" + sql);
                    }
                    dao.DaoClose();
                }
                
            }
            catch
            {
                MessageBox.Show("请在表格中选中要删除的图书记录", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // 把值 通过构造函数传到 修改图书的页面中
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string name = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string author = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                string prees = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                string number = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                admin22 admin = new admin22(id,name,author,prees,number);
                admin.ShowDialog();
                Table(); // 刷新数据
            }
            catch
            {
                MessageBox.Show("ERROR");
            }
           

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Table();
            textBox1.Text = "";
            textBox2.Text = "";
        }
        /// <summary>
        /// 书号查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            TableID();
           
        }
        /// <summary>
        /// 书名查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {
            TableName();
           
        }
       

        /// <summary>
        /// 多行删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        

        private void btn7_Click(object sender, EventArgs e)
        { 
            int n = dataGridView1.SelectedRows.Count; // 获取当前选中的行数

            string sql = $"delete from t_book where id in (";
            for (int i = 0; i < n; i++)
            {
                sql += $"'{dataGridView1.SelectedRows[i].Cells[0].Value.ToString()}',";
            }
            
            sql= sql.Remove(sql.Length - 1);// 删除最后一个字符
            sql += ")";
            if (n > 1)
            {
                Dao dao = new Dao();
                if (dao.Execute(sql) > n - 1)
                {
                    MessageBox.Show($"成功删除{n}条图书信息");
                    Table();
                }
            }
            else
            {
                MessageBox.Show("选择的行数少于2");
            }
           
        }
    }
}
