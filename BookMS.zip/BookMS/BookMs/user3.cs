﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class user3 : Form
    {
        public user3()
        {
            InitializeComponent();
            Table();
        }
      
        public void Table()
        {
            dataGridView1.Rows.Clear(); // 清空旧数据
            Dao dao = new Dao();
            string sql = $"select [no],[bid],[datetime] from t_lend where [uid]='{Data.UID}'";
             
            IDataReader dc = dao.read(sql); // 读取数据库到的数据返回到dc
            // 可以定义
            //string a0, a1, a2, a3, a4; // 来接收dc中的数据
            while (dc.Read())
            {
                // 这个方法 可以更好的修改数据 或添加数据
                //a0 = dc[0].ToString();
                //string[] table = { a0, a1, a2, a3, a4 };
                //dataGridView1.Rows.Add(table);
                // 一行一行的进行读写 这个方法简单粗暴
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString()) ;
            }
            dc.Close();
            dao.DaoClose();
        }
        private void user3_Load(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string no = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string id = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string sql = $"delete from t_lend where [no] ={no};update t_book set number=number+1 where id='{id}'";
                Dao dao = new Dao();
                if (dao.Execute(sql) > 1)
                {
                    Table();
                    MessageBox.Show("归还成功");
                    
                }
            }
            catch
            {
                MessageBox.Show("没有借阅记录");
            }
           
            
          
              
            
        }
    }
}
