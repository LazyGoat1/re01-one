﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class login1 : Form
    {
        public login1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                login();
            }
            else
            {
                MessageBox.Show("请输入账号或密码");
            }
        }
        /// <summary>
        /// 登录方法 验证是否允许登录 通过数据库中的 t_user 和pwd 以及 T_admin 中的 t_admin和psd 进行判断
        /// 如果输入的账号和密码对应不到amdin和user表中的值则登录失败哦
        /// </summary>
        public void login()   
        {
            // 判断用户单选 是否选中
            if (radioButtonUser.Checked == true)
            {
                Dao dao = new Dao();
                // 3种写法
                // string sql = "select * from t_user where id='"+textBox1.Text+"' and pwd='"+textBox2.Text+"';";
                //  string sql2=String.Format("select * from t_user where id='{0}' and pwd='{1}' ",textBox1.Text,textBox2.Text);
                string sql = $"select * from t_user where id='{textBox1.Text}'and pwd='{textBox2.Text}'";
                IDataReader dc = dao.read(sql);
                // dc[0] 等于 第一行第一个的字段 
                //MessageBox.Show(dc[0].ToString() + dc[1].ToString());
                if (dc.Read())
                {
                    Data.UID = dc["id"].ToString(); // 把登录的id 赋值给UID
                    Data.UName=dc["name"].ToString();    // 把登录的Uname 赋值给 Uname
                    MessageBox.Show("登录成功");

                    user1 user = new user1();
                    this.Hide();
                    user.ShowDialog();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("登录失败");
                }
                dao.DaoClose(); // 关闭数据库的连接
            }
            // 判断管理员单选是否选中
            if (radioButtonAdmin.Checked == true)
            {
                Dao dao=new Dao();
                string sql = $"select * from t_admin where id='{textBox1.Text}'and psw='{textBox2.Text}'";
                IDataReader dc = dao.read(sql);
                if (dc.Read())
                {
                    MessageBox.Show("登录成功");
                    admin1 admin = new admin1();

                    //this.Show();
                    // 表示 弹出新窗体 还可以操作旧窗体  admin.Show();

                    this.Hide();
                    admin.ShowDialog();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("登录失败");
                }
                dao.DaoClose();
            }
            

        }

        private void login1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close(); // 退出当前窗口
        }
    }
}
